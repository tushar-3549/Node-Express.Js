const express = require("express");
const app = express();
const PORT = 8800;

app.get("/", (req, res)=>{
    res.sendFile(__dirname +"/index.html");
})

app.use(express.static("public"));

app.listen(PORT, ()=>{
    console.log(`Server is working at: http://localhost:${PORT}`);
})