const express = require("express");
const router = express.Router();

router.get("/contact", (req, res) => {
  res.send("<h1>I am a get request at contact route</h1>");
});

router.get("/login", (req, res) => {
  res.send("<h1>I am a get request at login route</h1>");
});

module.exports = router;