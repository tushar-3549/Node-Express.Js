const express = require("express");
const router = express.Router();

router.get("/about",(req, res)=>{
    res.send("About route");
})

router.get("/login",(req, res)=>{
    res.send("login route");
})

module.exports = router;