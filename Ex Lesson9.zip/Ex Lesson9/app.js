const express = require('express');
const app = express();
const userRouter = require("./routes/users.route");
app.use("/api/user",userRouter);

app.use("/register",(req, res)=>{
    // res.send("Register Page");
    /* res.status(200).json({
        message: "Register Page",
        statusCode: 200,
    }) */
    // res.redirect("/login");
    res.statusCode = 200;
    res.sendFile(__dirname+"/views/register.html");
})

// app.use("/education",(req, res)=>{
//     res.send("Education Page");
// })

app.get("/education",(req, res)=>{
  res.cookie("name", "Tushar");
  res.cookie("age", "23");
//   res.clearCookie("name");
//   res.append("id", "130000");
  res.end();
})


app.use("/",(req, res)=>{
    // res.send("Home Page");
    res.statusCode = 200;
    res.sendFile(__dirname+"/views/index.html");
})

app.use((req,res)=>{
    res.send("404 Error! Not Found");
})

module.exports = app;