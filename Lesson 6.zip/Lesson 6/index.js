const randomMovieNames = require('random-movie-names');
// console.log(randomMovieNames());
console.log(randomMovieNames(5));