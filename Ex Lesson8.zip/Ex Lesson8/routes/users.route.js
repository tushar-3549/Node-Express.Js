const express = require("express");
const router = express.Router();

router.get("/", (req, res)=>{
    res.send("<h1>GET request from home route</h1>");
})

router.get("/about", (req, res)=>{
    res.send("<h1>GET request from about route</h1>");
})

router.get("/signin", (req, res)=>{
    res.send("<h1>GET request from Sign-in route</h1>");
})

router.get("/login", (req, res)=>{
    res.send("<h1>GET request from login route</h1>");
})

module.exports = router;