const express = require("express");
const app = express(); // express module

/* app.get("/", (req, res)=>{
    res.send("GET request from home route");
})
app.get("/about", (req, res)=>{
    res.send("GET request from about route");
}) */

/* 
app.get("/", (req, res)=>{
    res.send("GET request from home route");
})

// to show this need to run at postman

app.post("/", (req, res)=>{
    res.send("POST request from home route");
})


app.put("/", (req, res)=>{
    res.send("PUT request from home route");
})


app.delete("/", (req, res)=>{
    res.send("DELETE request from home route");
    res.end();
}) */


/* app.get("/", (req, res)=>{
    res.send("<h1>GET request from home route</h1>");
})

app.get("/about", (req, res)=>{
    res.send("<h1>GET request from about route</h1>");
})

app.get("/signin", (req, res)=>{
    res.send("<h1>GET request from Sign-in route</h1>");
})

app.get("/login", (req, res)=>{
    res.send("<h1>GET request from login route</h1>");
}) */

const usersRouter = this.require("./routes/users.route");
app.use("/api/user",usersRouter);

app.use("/",(req, res)=>{
    res.send("<h1>Get request from home routes</h1>");
})

app.use((req, res)=>{
    res.send("<h1>404 Page Not Found</h1>");
})

module.exports = app;

