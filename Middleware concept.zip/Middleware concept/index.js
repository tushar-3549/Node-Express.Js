const express = require("express");
const app = express();
const PORT = 8800;

const myMalware = (req, res, next)=>{
    console.log("This is middleware function!");
    req.currentTime = new Date(Date.now());
    next();
}
app.use(myMalware);
app.get("/",myMalware,(req, res)=>{
    console.log("From home: "+req.currentTime);
    res.send(`<h1>I am from home route</h1>`)
});
app.get("/login",(req, res)=>{
    console.log("From login: "+req.currentTime);
    res.send(`<h1>I am from login route</h1>`)
});
app.listen(PORT, ()=>{
    console.log(`server is working at: http://localhost:${PORT}`);
});