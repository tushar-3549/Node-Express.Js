// http request, route parameter

const express = require("express");
const app = express();
var bodyParser = require('body-parser');
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }));

// parse application/json
app.use(bodyParser.json());

const PORT = 5500;

/* app.get("/",(req, res)=>{
    const id = req.query.id;
    const name = req.query.name;

    // const {id,name} = req.query;
    // res.send("I am home route");
    res.send(`<h2>Student id : ${id} <br> Student name : ${name}</h2>`);
}) */

/* app.get("/userId/:id/userAge/:age",(req,res)=>{
    const id = req.params.id;
    const age = req.params.age;

    res.send(`ID: ${id} <br> Age: ${age}`);
}) */


app.post("/user", (req, res)=>{
    const name = req.body.name;
    res.send(`Welcome : ${name}`);
})



app.listen(PORT, ()=>{
    console.log(`Server is working at http://localhost:${PORT}`);
})