const express = require("express");
const app = express();

const PORT = 5500;

// app.get("/students/:id([0-9]+)",(req, res)=>{
app.get("/students/:id([0-9]{3})",(req, res)=>{
    res.send(`<h1>Student ID: ${req.params.id}</h1>`);
})
app.get("/students/:title([a-zA-Z]{3})",(req, res)=>{
    res.send(`<h1>Course Title: ${req.params.title}</h1>`);
})
app.use("*",(req,res)=>{
    res.status(404).send({
        message:"InValid Route",
    });
});

app.listen(PORT, (req,res)=>{
    console.log(`Server is working at http://localhost:${PORT}`);
})