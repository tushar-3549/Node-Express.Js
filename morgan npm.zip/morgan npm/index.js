
const express = require("express");
const app = express();

const morgan = require("morgan");
// app.use(morgan("dev"));
app.use(morgan("combined"));

const PORT = 3000;
app.get("/code",(req,res)=>{
    res.send("Code Page");
})
app.get("/",(req, res)=>{
    res.send("<h1>Welcome</h1>");
})
app.post("/code",(req, res)=>{
    res.send("<h1>Create Code</h1>");
})
app.listen(PORT, ()=>{
    console.log(`Server is running on: http://localhost:${PORT}`);
})