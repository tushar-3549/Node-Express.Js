const express = require("express");
const bodyParser = require("body-parser");
const app = express();

const PORT = 5500;

app.use(bodyParser.urlencoded({ extended: false }));

app.use(bodyParser.json());

app.get("/",(req,res)=>{
    // res.send("hi");
    res.sendFile(__dirname + "/index.html");
})

app.get("/addition",(req,res)=>{
    res.sendFile(__dirname + "/add.html");
})

app.get("/subtraction",(req,res)=>{
    res.sendFile(__dirname + "/sub.html");
})


app.post("/add", (req, res) => {
    const x = parseInt(req.body.num1); 
    const y = parseInt(req.body.num2); 
    const sum = x + y;
    res.send(`<h2>Summation : ${sum}</h2>`);
});

app.post("/sub", (req, res) => {
    const x = parseInt(req.body.num1); 
    const y = parseInt(req.body.num2); 
    const sub = x - y;
    res.send(`<h2>Subtraction : ${sub}</h2>`);
});


app.listen(PORT, ()=>{
    console.log(`Server is running at http://localhost:${PORT}`);
})